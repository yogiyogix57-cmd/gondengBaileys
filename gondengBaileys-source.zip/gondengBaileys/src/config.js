import 'dotenv/config';

export const config = {
  phoneNumber: (process.env.PHONE_NUMBER || '').replace(/\D/g, ''),
  newsletterJid: (process.env.NEWSLETTER_JID || '').trim(),
  logLevel: process.env.LOG_LEVEL || 'info',
  authDir: 'auth_info'
};
