import { startConnection } from './connection.js';
import { logger } from './logger.js';

process.on('unhandledRejection', error => {
  logger.error({ err: error }, 'Unhandled promise rejection');
});

process.on('uncaughtException', error => {
  logger.fatal({ err: error }, 'Uncaught exception');
  process.exit(1);
});

startConnection().catch(error => {
  logger.fatal({ err: error }, 'Bot gagal dijalankan');
  process.exit(1);
});
