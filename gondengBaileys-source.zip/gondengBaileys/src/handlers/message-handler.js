import { describeMessage } from '../message-utils.js';
import { logger } from '../logger.js';

export async function handleMessage(socket, message) {
  if (!message?.message || message.key?.fromMe) return;

  const info = describeMessage(message.message);
  const chat = message.key.remoteJid || 'unknown';
  const sender = message.key.participant || chat;

  logger.info({
    chat,
    sender,
    type: info.type,
    hasMedia: info.hasMedia
  }, 'Incoming message');

  // Tambahkan command bot milikmu di sini.
  // Jangan mengirim pesan otomatis ke semua chat; balas hanya sesuai interaksi pengguna.
  if (info.text.trim().toLowerCase() === '!ping') {
    await socket.sendMessage(chat, { text: 'Pong! gondengBaileys aktif.' }, {
      quoted: message
    });
  }
}
