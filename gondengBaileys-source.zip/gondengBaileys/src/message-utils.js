import { getContentType } from '@whiskeysockets/baileys';

export function unwrapMessage(message = {}) {
  let current = message;
  // Buka wrapper umum tanpa mengubah isi pesan.
  for (let i = 0; i < 6; i++) {
    const key = Object.keys(current || {}).find(k =>
      ['ephemeralMessage', 'viewOnceMessage', 'viewOnceMessageV2',
       'viewOnceMessageV2Extension', 'documentWithCaptionMessage'].includes(k)
    );
    if (!key) break;
    current = current[key]?.message || current;
  }
  return current || {};
}

export function describeMessage(message = {}) {
  const content = unwrapMessage(message);
  const type = getContentType(content) || 'unknown';
  const item = content[type] || {};
  const text = content.conversation
    || content.extendedTextMessage?.text
    || item.caption
    || item.text
    || '';

  return {
    type,
    text: typeof text === 'string' ? text : '',
    hasMedia: Boolean(item?.mimetype || item?.url || item?.directPath),
    isForwarded: Boolean(item?.contextInfo?.isForwarded),
    content
  };
}
