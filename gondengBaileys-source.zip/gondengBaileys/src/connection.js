import {
  makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  DisconnectReason,
  Browsers
} from '@whiskeysockets/baileys';
import { config } from './config.js';
import { logger } from './logger.js';
import { handleMessage } from './handlers/message-handler.js';

let reconnecting = false;

export async function startConnection() {
  const { state, saveCreds } = await useMultiFileAuthState(config.authDir);
  const { version } = await fetchLatestBaileysVersion();

  const socket = makeWASocket({
    version,
    auth: state,
    browser: Browsers.ubuntu('Chrome'),
    printQRInTerminal: false,
    logger: logger.child({ module: 'baileys' }),
    markOnlineOnConnect: false,
    syncFullHistory: false
  });

  socket.ev.on('creds.update', saveCreds);

  socket.ev.on('connection.update', async ({ connection, lastDisconnect }) => {
    if (connection === 'connecting') logger.info('Menghubungkan ke WhatsApp...');
    if (connection === 'open') {
      logger.info('WhatsApp berhasil terhubung.');
      await followConfiguredNewsletter(socket);
    }

    if (connection === 'close' && !reconnecting) {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode === DisconnectReason.loggedOut) {
        logger.error('Session logout. Hapus folder auth_info lalu pairing ulang.');
        return;
      }

      reconnecting = true;
      logger.warn({ statusCode }, 'Koneksi terputus. Mencoba reconnect...');
      setTimeout(async () => {
        reconnecting = false;
        try {
          await startConnection();
        } catch (error) {
          logger.error({ err: error }, 'Reconnect gagal.');
        }
      }, 3000);
    }
  });

  socket.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const message of messages) {
      try {
        await handleMessage(socket, message);
      } catch (error) {
        logger.error({ err: error }, 'Gagal memproses pesan.');
      }
    }
  });

  if (!state.creds.registered) {
    if (!config.phoneNumber) {
      logger.warn('Isi PHONE_NUMBER di file .env untuk meminta pairing code.');
      return socket;
    }
    // Beri waktu socket menyiapkan koneksi sebelum meminta kode.
    setTimeout(async () => {
      try {
        const code = await socket.requestPairingCode(config.phoneNumber);
        logger.info(`PAIRING CODE: ${code}`);
        logger.info('Masukkan kode tersebut di WhatsApp > Perangkat tertaut.');
      } catch (error) {
        logger.error({ err: error }, 'Gagal meminta pairing code.');
      }
    }, 2500);
  }

  return socket;
}

async function followConfiguredNewsletter(socket) {
  const jid = config.newsletterJid;
  if (!jid) return;
  if (!jid.endsWith('@newsletter')) {
    logger.warn('NEWSLETTER_JID tidak valid; harus berakhiran @newsletter.');
    return;
  }
  try {
    await socket.newsletterFollow(jid);
    logger.info({ jid }, 'Permintaan follow newsletter dikirim.');
  } catch (error) {
    logger.warn({ err: error, jid }, 'Tidak dapat follow newsletter.');
  }
}
