# gondengBaileys

Starter WhatsApp Multi-Device bot menggunakan Baileys dan JavaScript (Node.js 20+).

## Fitur

- Pairing code menggunakan nomor WhatsApp.
- Penyimpanan session multi-file di `auth_info/`.
- Reconnect ketika koneksi terputus (kecuali logout).
- Event handler pesan masuk dengan klasifikasi tipe pesan.
- Wrapper pesan umum: ephemeral, view-once, dan document-with-caption.
- Contoh command `!ping`.
- Newsletter follow opsional melalui `NEWSLETTER_JID`.
- Konfigurasi melalui `.env`.

> Baileys adalah library tidak resmi. Tidak ada jaminan semua tipe pesan atau fitur WhatsApp akan selalu kompatibel; API WhatsApp dapat berubah. Gunakan akun milik sendiri dan patuhi ketentuan WhatsApp. Hindari spam atau pesan massal.

## Instalasi

Pastikan Node.js 20 atau lebih baru tersedia.

```bash
npm install
cp .env.example .env
```

Edit `.env`:

```env
PHONE_NUMBER=628xxxxxxxxxx
NEWSLETTER_JID=
LOG_LEVEL=info
```

Jalankan:

```bash
npm start
```

Lihat terminal untuk pairing code. Di WhatsApp, buka **Perangkat tertaut** lalu pilih opsi menautkan dengan nomor telepon/kode pairing. Masukkan kode yang tampil di terminal.

Setelah berhasil, folder `auth_info/` akan menyimpan session. Jangan unggah folder tersebut atau file `.env` ke GitHub.

## Newsletter

Fitur ini opsional. Isi `NEWSLETTER_JID` dengan JID channel yang kamu pilih sendiri, berakhiran `@newsletter`. Kosongkan untuk menonaktifkan. Pastikan kamu memang ingin mengikuti channel tersebut.

## Struktur

```text
gondengBaileys/
├── src/
│   ├── handlers/
│   │   └── message-handler.js
│   ├── config.js
│   ├── connection.js
│   ├── index.js
│   ├── logger.js
│   └── message-utils.js
├── .env.example
├── .gitignore
├── LICENSE
├── package.json
└── README.md
```

## Menambahkan handler tipe pesan

`describeMessage()` mengembalikan `type`, `text`, `hasMedia`, dan objek `content`. Tambahkan pemrosesan khusus di `src/handlers/message-handler.js` sesuai kebutuhan. Media tidak diunduh otomatis pada starter ini.

## Lisensi

MIT. Lihat file `LICENSE`.
